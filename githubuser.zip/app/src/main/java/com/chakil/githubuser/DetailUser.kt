package com.chakil.githubuser

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView

class DetailUser : AppCompatActivity() {
    companion object {
        const val EXTRA_NAME = "extra_name"
        const val EXTRA_ID = "extra_id"
        const val EXTRA_COMPANY = "extra_company"
        const val EXTRA_PHOTO = "extra_photo"
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_user)

        val ivUserPhoto: ImageView = findViewById(R.id.detail_img)
        val tvUserName: TextView = findViewById(R.id.detail_name)
        val tvUserId: TextView = findViewById(R.id.detail_id)
        val tvUserCompany: TextView = findViewById(R.id.detail_company)

        val userName = intent.getStringExtra(EXTRA_NAME)
        val userId = intent.getStringExtra(EXTRA_ID)
        val userCompany = intent.getStringExtra(EXTRA_COMPANY)

        tvUserName.text = userName
        tvUserId.text = userId
        tvUserCompany.text = userCompany
    }
}